import { useState } from "react";
import "./App.css";
import Home from "./app/home";
import AuthLayout from "./components/authLayout";
import SignUp from "./app/auth/signUp";
import Login from "./app/auth/login";
import Profile from "./app/auth/profile";
function App() {

  return (
    <>
        <SignUp />
        {/* <Login/> */}
        {/* <Profile/> */}
    </>
  );
}

export default App;
