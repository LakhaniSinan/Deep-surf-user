export const homeData = {
    heading: "AI-driven Trading Intelligence Engine",
    subHeading: "Powered by proprietary machine learning models, real-time market data, and years of quantitative research."
};

export default homeData;